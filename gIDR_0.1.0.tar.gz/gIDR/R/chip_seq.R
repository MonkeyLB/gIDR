#' @title chip_seq
#' @description A matrix of two columns. Each column is a replicate of ChIP-seq data. The observations are the read counts from genomic locations.
#'
"chip_seq"
